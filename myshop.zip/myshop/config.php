<?php

session_start();
$dbHost = 'localhost';
$dbName = 'myshop';
$dbUsername = 'root';
$dbPassword = '';
$dbConnect = mysqli_connect($dbHost,$dbUsername,$dbPassword,$dbName) or die('connection failed');

?>